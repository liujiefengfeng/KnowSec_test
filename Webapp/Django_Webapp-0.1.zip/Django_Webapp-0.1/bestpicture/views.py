from django.http import HttpResponse
from bestpicture.models import Picture
from django.shortcuts import render, get_object_or_404
from django.template import Context, loader

def index(request):
    latest_pic_list = Picture.objects.order_by('-good')[:5]
    context = {
            'latest_pic_list' : latest_pic_list,
            }
    return render(request, 'bestpicture/index.html',context)

def detail(request, pic_id):
    picture = get_object_or_404(Picture, pk=pic_id)
    return render(request, 'bestpicture/detail.html', {'picture': picture})

def vote(request, pic_id):
    picture = get_object_or_404(Picture, pk=pic_id)
    picture.good += 1
    picture.save()
    return render(request, 'bestpicture/results.html', {'picture': picture})
    
def results(request, pic_id):
    picture = get_object_or_404(picture, pk=pic_id)
    return render(request, 'bestpicture/results.html', {'picture': picture})