from django.contrib import admin

# Register your models here.
from django.contrib import admin
from bestpicture.models import Picture


class PictureAdmin(admin.ModelAdmin):

    fieldsets = [
        ('picture_url',               {'fields': ['picture']}),
        ('comment',                   {'fields': ['good']}),
    ]
    
admin.site.register(Picture, PictureAdmin)
